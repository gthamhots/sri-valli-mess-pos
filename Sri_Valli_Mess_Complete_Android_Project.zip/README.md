# Sri Valli Mess POS — Android APK project

This is an **Android source project**, not a precompiled APK. The offline HTML billing app is bundled in `app/src/main/assets/index.html`.

## Free GitHub Actions build

Upload **all files and folders at the repository root**, including the hidden `.github` folder, then open **Actions → Build Sri Valli Mess POS APK → Run workflow**. After a successful run, download **Sri-Valli-Mess-POS-APK** from the run's Artifacts section, unzip and install `app-debug.apk`.

GitHub repository: https://github.com/gthamhots/sri-valli-mess-pos

## Notes

- Bills are stored in the app's local WebView storage, not a cloud database. Uninstalling the app or clearing app data can erase them. Export a JSON backup frequently.
- Printing uses the Android system print dialog; verify compatibility with your receipt printer.
- The debug APK is for personal testing, not a signed production release.
- Building requires GitHub Actions access and internet on GitHub's build runner; the app itself uses bundled assets offline.
- Export to Downloads uses Android 10+.
