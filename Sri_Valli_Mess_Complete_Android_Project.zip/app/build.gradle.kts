plugins { id("com.android.application") }

android {
    namespace = "in.srivallimess.pos"
    compileSdk = 35
    defaultConfig {
        applicationId = "in.srivallimess.pos"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
