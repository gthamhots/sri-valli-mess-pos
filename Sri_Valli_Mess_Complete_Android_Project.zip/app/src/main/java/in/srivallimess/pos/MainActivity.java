package in.srivallimess.pos;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Build;
import android.print.PrintAttributes;
import android.print.PrintManager;
import android.provider.MediaStore;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient.FileChooserParams;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    private WebView webView;
    private ValueCallback<Uri[]> filePathCallback;
    private static final int FILE_CHOOSER_REQUEST = 1001;
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        webView = new WebView(this);
        setContentView(webView);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        webView.addJavascriptInterface(new AndroidPOS(), "AndroidPOS");
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (filePathCallback != null) filePathCallback.onReceiveValue(null);
                filePathCallback = callback;
                Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("application/json");
                try { startActivityForResult(Intent.createChooser(intent, "Select POS backup"), FILE_CHOOSER_REQUEST); }
                catch (Exception e) { filePathCallback = null; Toast.makeText(MainActivity.this, "Could not open file picker", Toast.LENGTH_LONG).show(); return false; }
                return true;
            }
        });
        webView.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView view, String url) {
                view.evaluateJavascript("window.print = function(){ AndroidPOS.printReceipt(); };", null);
            }
        });
        webView.loadUrl("file:///android_asset/index.html");
    }
    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_CHOOSER_REQUEST && filePathCallback != null) {
            Uri result = (resultCode == RESULT_OK && data != null) ? data.getData() : null;
            filePathCallback.onReceiveValue(result == null ? null : new Uri[]{result});
            filePathCallback = null;
        }
    }
    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }
    public class AndroidPOS {
        @JavascriptInterface public void printReceipt() { runOnUiThread(() -> {
            try {
                PrintManager pm = (PrintManager) getSystemService(PRINT_SERVICE);
                String jobName = "Sri Valli Mess Receipt";
                pm.print(jobName, webView.createPrintDocumentAdapter(jobName), new PrintAttributes.Builder().build());
            } catch (Exception e) { Toast.makeText(MainActivity.this, "Printing is not available on this device", Toast.LENGTH_LONG).show(); }
        }); }
        @JavascriptInterface public void saveTextFile(String name, String content, String mime) {
            runOnUiThread(() -> {
                try {
                    if (Build.VERSION.SDK_INT < 29) { Toast.makeText(MainActivity.this, "Export requires Android 10 or newer", Toast.LENGTH_LONG).show(); return; }
                    ContentValues values = new ContentValues();
                    values.put(MediaStore.Downloads.DISPLAY_NAME, name.replaceAll("[^A-Za-z0-9._-]", "_"));
                    values.put(MediaStore.Downloads.MIME_TYPE, mime == null ? "text/plain" : mime);
                    values.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
                    Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
                    if (uri == null) throw new Exception("Could not create download");
                    try (OutputStream out = getContentResolver().openOutputStream(uri)) { out.write(content.getBytes(StandardCharsets.UTF_8)); }
                    Toast.makeText(MainActivity.this, "Saved to Downloads", Toast.LENGTH_LONG).show();
                } catch (Exception e) { Toast.makeText(MainActivity.this, "Could not save file: " + e.getMessage(), Toast.LENGTH_LONG).show(); }
            });
        }
    }
}
